def setup():
    print 'package1 setup'
