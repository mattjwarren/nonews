Capture: capture stdout during tests
====================================

.. autoplugin :: nose.plugins.capture

