.. automodule :: nose.proxy
   :members: